﻿/* nombre : fernanjps3A  */
class Program
{
    public static void Main(string[] args)
    {
        Empleados empleados = new Empleados("Bar de comida", 2022, "fer", "fernandez", 1, "Soltero");
        empleados.imprimir();
        Estudiantes estudiante = new Estudiantes("A340", "Pablo", "ramires", 2, "Soltero");
        estudiante.imprimir();
        Personal personal = new Personal("Secretaria", "Dayana", "rivas", 3, "Casada");
        personal.imprimir();
        Profesores profesores = new Profesores("tecnologias de la informacion", "Joaquin", "Gonzales", 3, "viudo");
        profesores.imprimir();
    }
}
